# Experiment 1 - Introduction to Keras

## Aim
To understand the basics of neural networks using Keras and TensorFlow.

## Software Used
- Python
- TensorFlow
- Keras
- NumPy
- Matplotlib
- Scikit-learn

## Files Included
- Intro Keras.ipynb
- Demo_RetinaNet.ipynb
- data_download.ipynb
- solutions folder

## Description
This experiment demonstrates:
- Loading datasets
- Data preprocessing
- Train-test split
- Neural network training using Keras
- Model evaluation

## Output
The notebook trains a neural network model on handwritten digit data and evaluates prediction accuracy.
